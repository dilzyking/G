# PITCHSIDE (static / GitHub Pages version)

Same site, no backend required. The API was pre-built into small, paginated
JSON files at build time (see `build_static.py`), so the browser still only
ever fetches one small chunk at a time — same lazy-loading behaviour as the
Node version, just with the "server" baked in ahead of time.

## Deploy on GitHub Pages — step by step

1. **Create a repo on GitHub** (github.com → New repository). Any name is fine,
   e.g. `pitchside`.

2. **Push this folder to it** (run these in this project's folder):
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
   git push -u origin main
   ```

3. **Turn on Pages**:
   - On GitHub, go to your repo → **Settings** → **Pages** (left sidebar).
   - Under "Build and deployment" → Source: **Deploy from a branch**.
   - Branch: **main**, folder: **/docs** → **Save**.

4. Wait ~1 minute, then refresh that Settings → Pages screen — it'll show your
   live URL:
   - `https://YOUR-USERNAME.github.io/YOUR-REPO/`

That's it — no server, no build step on GitHub's side, just static files.

## Updating the data later

Edit the source JSON in `server-data-source/*.json` (kept alongside for
reference), then regenerate the static files:
```bash
python3 build_static.py
```
This rewrites everything under `docs/data/`. Commit and push, and Pages picks
up the new files automatically.

## Notes

- All asset/data paths are **relative** (`css/style.css`, `data/...`, not
  `/css/style.css`), so this works whether it's a user site
  (`username.github.io`) or a project site (`username.github.io/repo-name/`).
- If you'd rather keep the real Node API (dynamic filtering, no pre-baked
  files, easy to hook up a real data feed later), use the other version of
  this project and host it on Render/Railway/Fly.io instead — GitHub Pages
  itself can't run a server.
