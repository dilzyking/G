import json, os, itertools

SRC = "server-data-source"
OUT = "docs/data"

matches = json.load(open(f"{SRC}/matches.json"))
groups = json.load(open(f"{SRC}/groups.json"))
teams = json.load(open(f"{SRC}/teams.json"))
highlights = json.load(open(f"{SRC}/highlights.json"))

MATCH_LIMIT = 8
HIGHLIGHT_LIMIT = 6

def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)

def paginate_and_write(items, base_path, limit):
    items = sorted(items, key=lambda m: (m["date"] + m.get("kickoff", "")))
    if not items:
        write(f"{base_path}/page-1.json", {
            "page": 1, "limit": limit, "total": 0, "hasMore": False, "results": []
        })
        return
    total = len(items)
    page = 1
    for start in range(0, total, limit):
        chunk = items[start:start + limit]
        has_more = start + limit < total
        write(f"{base_path}/page-{page}.json", {
            "page": page, "limit": limit, "total": total,
            "hasMore": has_more, "results": chunk,
        })
        page += 1

# ---- matches: all / by group / by status / by group+status ----
paginate_and_write(matches, f"{OUT}/matches/all", MATCH_LIMIT)

group_letters = list(groups.keys())
statuses = ["live", "upcoming", "finished"]

for g in group_letters:
    subset = [m for m in matches if m["group"] == g]
    paginate_and_write(subset, f"{OUT}/matches/group/{g}", MATCH_LIMIT)

for s in statuses:
    subset = [m for m in matches if m["status"] == s]
    paginate_and_write(subset, f"{OUT}/matches/status/{s}", MATCH_LIMIT)

for g, s in itertools.product(group_letters, statuses):
    subset = [m for m in matches if m["group"] == g and m["status"] == s]
    paginate_and_write(subset, f"{OUT}/matches/group-status/{g}-{s}", MATCH_LIMIT)

# ---- live matches (small, eager-loaded file) ----
live = [m for m in matches if m["status"] == "live"]
write(f"{OUT}/matches/live.json", {"count": len(live), "results": live})

# ---- groups list + per-group standings ----
write(f"{OUT}/groups.json", [
    {"letter": g, "teams": t} for g, t in groups.items()
])

def standings_for(letter):
    table = {t["code"]: {**t, "played": 0, "won": 0, "drawn": 0, "lost": 0,
                          "gf": 0, "ga": 0, "points": 0} for t in groups[letter]}
    for m in matches:
        if m["group"] != letter or m["status"] != "finished":
            continue
        h, a = table.get(m["home"]["code"]), table.get(m["away"]["code"])
        if not h or not a:
            continue
        h["played"] += 1; a["played"] += 1
        h["gf"] += m["home_score"]; h["ga"] += m["away_score"]
        a["gf"] += m["away_score"]; a["ga"] += m["home_score"]
        if m["home_score"] > m["away_score"]:
            h["won"] += 1; a["lost"] += 1; h["points"] += 3
        elif m["home_score"] < m["away_score"]:
            a["won"] += 1; h["lost"] += 1; a["points"] += 3
        else:
            h["drawn"] += 1; a["drawn"] += 1; h["points"] += 1; a["points"] += 1
    rows = list(table.values())
    rows.sort(key=lambda t: (-t["points"], -(t["gf"] - t["ga"]), -t["gf"]))
    return rows

for g in group_letters:
    write(f"{OUT}/groups/{g}.json", {"letter": g, "standings": standings_for(g)})

# ---- highlights ----
paginate_and_write_highlights_dir = f"{OUT}/highlights"
sorted_highlights = highlights  # keep given order
total = len(sorted_highlights)
page = 1
for start in range(0, total, HIGHLIGHT_LIMIT):
    chunk = sorted_highlights[start:start + HIGHLIGHT_LIMIT]
    has_more = start + HIGHLIGHT_LIMIT < total
    write(f"{OUT}/highlights/page-{page}.json", {
        "page": page, "limit": HIGHLIGHT_LIMIT, "total": total,
        "hasMore": has_more, "results": chunk,
    })
    page += 1

print("Static JSON tree built at", OUT)
